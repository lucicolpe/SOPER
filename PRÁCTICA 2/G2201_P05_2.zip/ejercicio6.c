/**
*@brief Implementación del ejercicio 6 que crea dos procesos. El proceso hijo escribe continuamente un texto cada 5 segundos. El padre espera 30 segundos u entonces para los dos procesos
 * @author Lucia Colmenarejo Perez y Jesus D. Franco Lopez
 *        lucia.colmenarejo@estudiante.uam.es  y jesus.franco@estudiante.uam.es
 * Grupo 2201 Pareja 5
 * @version 1.0
 * @date 15-03-2017
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

/**
* @brief funcion en la que generamos los procesos y sus funcionalidades especificadas por el enunciado (dormir).
* @param 
* @return int: valor de exito o fracaso
*/

int main(){
    int fpid;
    fpid = fork();
    if(fpid < 0){
        printf("Error al emplear el fork.");
        return -1;
    }
    if(!fpid){
        while(1){
            printf("Soy el proceso hijo con PID: %d\n", getpid());
            fflush(stdout);
            sleep(5);/*Se manda dormir al hijo*/
        }
    }
    else{
        sleep(30);/*Se manda dormir al padre*/
        kill(fpid, SIGHUP);/*Se manda una señal de finalizacón cualquiera al hijo*/
        return 0;
    }
    return 0;
}

