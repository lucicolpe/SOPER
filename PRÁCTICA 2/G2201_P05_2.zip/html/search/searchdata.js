var indexSectionsWithContent =
{
  0: "_dfmno",
  1: "_",
  2: "dfmno"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Variables"
};

