/**
*@brief Implementación del ejercicio 10, que genera un par de procesos de acuerdo a los requerimientos estipulados por el enuniado. El proceso A seleccionará una palabra aleatoria de la cadena dada, la escribe en cadena.txt y termina. El proceso B ller una palabra cada 5 segundos del fichero. Si el valor leido es FIN entiende que A ha muerto y lo genera de nuevo. Mata al proceso A y a él mismo al leer 50 cadenas.
 * @author Lucia Colmenarejo Perez y Jesus D. Franco Lopez
 *        lucia.colmenarejo@estudiante.uam.es  y jesus.franco@estudiante.uam.es
 * Grupo 2201 Pareja 5
 * @version 1.0
 * @date 15-03-2017
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

/**
* @brief Definicion de la macro NUMPALABRAS
*/
#define NUMPALABRAS 13 /*Numero de palabras del fichero*/

/**
* @brief funcion del manejador muy simple debido a la decisión de no hacerlo
*        con variables globales.
* @param sig señal pasada
*/

void captura(int sig){
    return;
}

/**
* @brief funcion en la que generamos los procesos A y B y sus funcionalidades requeridas.
* @param 
* @return int: valor de exito o fracaso
*/

int main (){
    int ret = 0;
    int pid;
    int i = 0;
    int cont = 0;
    int aux;
    char string[] = "EL PROCESO A ESCRIBE EN UN FICHERO HASTA QUE LEE LA CADENA FIN";
    char* palabras[NUMPALABRAS];
    char* token;
    char auxA[NUMPALABRAS];
    sigset_t set, oset, mask;
    FILE* fp = NULL;
    FILE* fh = NULL;

    fp = fopen("cadena.txt", "w");
    if(fp == NULL){
        printf("Error al abrir el fichero.\n");
        exit(EXIT_FAILURE);
    }
    fclose(fp);

    token = strtok(string, " ");
    while(token != NULL){
        palabras[i] = token;
        token = strtok(NULL, " ");
        i++;
    }

    /*Creamos los procesos mediante el uso de fork()*/
    if ((pid=fork()) == -1){
        printf("Error al emplear fork\n");
        exit(EXIT_FAILURE);
    }

    while(1){
        if(pid == 0){
            if(sigfillset(&set) == -1){
                printf("Error al bloquear las señales.\n");
                exit(EXIT_FAILURE);
            }
            if(sigdelset(&set, SIGUSR2) == -1){
                printf("Error al desenmascarar la señal SIGUSR2.\n");
                exit(EXIT_FAILURE);
            }
            if(sigprocmask(SIG_SETMASK, &set, &oset) == -1){
                printf("Error al enmascarar las señales.\n");
                exit(EXIT_FAILURE);
            }
            while(1){
                fh = fopen("cadena.txt", "a");
                if(fh == NULL){
                    printf("Error al abrir el fichero.\n");
                    exit(EXIT_FAILURE);
                }
                aux = rand()%NUMPALABRAS;
                fprintf(fh, "%s ", palabras[aux]);
                printf("\nHIJO %d escribe la palabra %s: \n", getpid(), palabras[aux]);
                fflush(stdout);
                fclose(fh);
                kill(getppid(), SIGUSR1);
                if(strcmp(palabras[aux], "FIN") == 0){
                    exit(EXIT_SUCCESS);
                }
                if(signal(SIGUSR2, captura) == SIG_ERR){
                    printf("Error en la señal SIGUSR2\n");
                    exit(EXIT_FAILURE);
                }
                sigsuspend(&set);
            }
        }

        else if(pid > 0){
            if(sigfillset(&mask) == -1){
                printf("Error al enmascarar las señales.\n");
                exit(EXIT_FAILURE);
            }
            if(sigdelset(&mask, SIGUSR1) == -1){
                printf("Error al desenmascarar la señal SIGUSR1.\n");
                exit(EXIT_FAILURE);
            }
            while(cont < 50){
                if(signal(SIGUSR1, captura) == SIG_ERR){
                    printf("Error en la señal SIGUSR1\n");
                    exit(EXIT_FAILURE);
                }
                sigsuspend(&mask);
                sleep(5);
                fp = fopen("cadena.txt", "r");
                if(fp == NULL){
                    printf("Error al abrir el fichero.\n");
                    exit(EXIT_FAILURE);
                }
                fseek(fp, ret, SEEK_SET);
                fscanf(fp, "%s", auxA);
                printf("Padre lee cadena %d: %s \n", cont+1, auxA);
                fflush(stdout);
                ret = ftell(fp);
                cont++;
                fclose(fp);
                if(strncmp(auxA, "FIN", 3) == 0){
                    wait(NULL);
                    srand(time(NULL));
                    if ((pid=fork()) == -1){
                        printf("Error al emplear fork\n");
                        exit(EXIT_FAILURE);
                    }
                    if(pid == 0){
                        break;
                    }
                } else {
                    kill(pid, SIGUSR2);
                }
            }

            if(pid > 0){
                kill(pid, SIGKILL);
                wait(NULL);
                exit(EXIT_SUCCESS);
            }
        }
    }
    exit(EXIT_SUCCESS);
}
