var searchData=
[
  ['dado',['dado',['../carrera_8c.html#a83f626771b5b3808daffc8c86c50ad9a',1,'carrera.c']]]
];
