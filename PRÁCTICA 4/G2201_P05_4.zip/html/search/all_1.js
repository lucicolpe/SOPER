var searchData=
[
  ['apostador',['apostador',['../carrera_8c.html#a3fd75a1b94e82a20948426fe10321d90',1,'carrera.c']]],
  ['apuesta',['apuesta',['../carrera_8c.html#ae7b6ac6fb6245174285b53c4dcd06baf',1,'carrera.c']]]
];
