var searchData=
[
  ['id',['id',['../struct__Mensaje.html#a216a370cde3eae04df6a81fea5bef338',1,'_Mensaje']]]
];
