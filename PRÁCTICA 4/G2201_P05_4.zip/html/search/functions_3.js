var searchData=
[
  ['gestor',['gestor',['../carrera_8c.html#a6355e8351cb70809af3820ac0ba09210',1,'gestor(int shmid, int numCaballos, int numApostadores, int ventanillas, carrera caballos[MAX]):&#160;carrera.c'],['../carrera_8c.html#ad9e9a09017727a6af95e993c208850ca',1,'gestor(int shmid, int numCaballos, int numApostadores, int ventanillas, carrera *caballos):&#160;carrera.c']]]
];
