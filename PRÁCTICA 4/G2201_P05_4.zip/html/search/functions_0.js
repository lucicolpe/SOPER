var searchData=
[
  ['apostador',['apostador',['../carrera_8c.html#a3fd75a1b94e82a20948426fe10321d90',1,'carrera.c']]]
];
