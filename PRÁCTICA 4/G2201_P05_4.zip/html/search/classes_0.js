var searchData=
[
  ['_5fapuesta',['_Apuesta',['../struct__Apuesta.html',1,'']]],
  ['_5fcaballo',['_Caballo',['../struct__Caballo.html',1,'']]],
  ['_5fcarrera',['_Carrera',['../struct__Carrera.html',1,'']]],
  ['_5fmensaje',['_Mensaje',['../struct__Mensaje.html',1,'']]],
  ['_5fmonitor',['_Monitor',['../struct__Monitor.html',1,'']]],
  ['_5fventanilla',['_Ventanilla',['../struct__Ventanilla.html',1,'']]]
];
