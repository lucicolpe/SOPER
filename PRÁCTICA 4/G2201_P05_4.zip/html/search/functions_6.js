var searchData=
[
  ['ventanilla',['ventanilla',['../carrera_8c.html#a8bb83c437a2f9ee43d6c53832837513e',1,'carrera.c']]]
];
