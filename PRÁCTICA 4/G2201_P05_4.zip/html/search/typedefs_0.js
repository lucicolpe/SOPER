var searchData=
[
  ['apuesta',['apuesta',['../carrera_8c.html#ae7b6ac6fb6245174285b53c4dcd06baf',1,'carrera.c']]]
];
