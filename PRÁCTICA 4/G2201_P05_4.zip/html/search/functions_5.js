var searchData=
[
  ['pantalla',['pantalla',['../carrera_8c.html#ae7e84335952f7e2aed47abcb101eaab7',1,'carrera.c']]]
];
